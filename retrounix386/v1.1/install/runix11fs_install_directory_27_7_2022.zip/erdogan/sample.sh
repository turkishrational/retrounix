/usr/bin/hello
echo "Directory :"
ls -l .
