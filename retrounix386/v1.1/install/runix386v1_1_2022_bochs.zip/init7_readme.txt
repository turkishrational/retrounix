init7 is a simplified /etc/init for Retro UNIX 386 v1.1 & v1.2; 
it does not contain fd1 mounting, 
/tmp/utmp and /tmp/wtmp file recording code.
(source code: init7.s)
***
Erdogan Tan - 10/02/2022

