; 18/02/2022 - Erdogan Tan - Istanbul

*** Retro UNIX 386 v1.2 test notes ***

type "?" at boot prompt

For example:
boot: ?  (see valid commands)

boot: unix  (launch retro unix kernel with name 'unix')

(presss any key to continue to when unix startup (status) message appears)

*** 

unix login prompt...

root (superuser) password: enter key

erdogan (user) password: 417

press ATLT+F1 to ALT+F8 for multiscreen test

pseudo ttys: (multiscreen)

tty6 (video page 6) displays a timer (for testing) when multitasking is not enabled
     (multi tasking clock/scheduler will be used in multitasking mode instead of test clock)
 
tty7 (video page 7) displays current date and time (rtc test)

tty0 to tty5 are login screens (also tty6 and tty7 are login screens)

tty8 and tty9 are serial port COM1, COM2 (they can not be used in bochs emulator)

in single user mode: 
	multiscreen (multiuser login) feature will not be enabled 
	but video page 6 & 7 will display time and date (ALT+F6, ALT+F7)

/etc directoy contains
	motd (startup message), init, getty, passwd files

/bin directory contains

	cat, login, ls, sample.sh, sh files

	command example: sh sample.sh
			 ls -l .

/usr/bin directory contains 

	(if fd1 is mounted) root directory of the mounted (runix v1.2) fs
	(if fd1 is not mounted) hello (sample program)

/erdogan directory contains

	args, clock, forktest, scancode, ttydemo, cls binaries and mailbox text file

	for example: cat mailbox

****

if you write 'fd0.img' file to a real 1.44MB floppy disk 
(via 'rawwritewin.exe' or another program for image to disk write)
Retro UNIX 386 v1.1 operating system (project/working) will run on
real computer if that IBM PC compatible computer has a 1.44 MB floppy drive 
(and the cpu is one of 80386, 80486, Pentium and later CPUs) 